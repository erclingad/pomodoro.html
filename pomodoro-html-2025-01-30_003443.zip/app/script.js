const pomodoroT = document.getElementById("pomodoroTimer");
const shortBreak = document.getElementById("shortBreak");
const longBreak = document.getElementById("longBreak");
const start = document.getElementById("start").addEventListener("click", startTimer);
const stop = document.getElementById("stop").addEventListener("click", stopTimer);
const reset = document.getElementById("reset").addEventListener("click", resetTimer);

let interval;
let timeLeft = 1500;

function timeUpdate() {
  let min = Math.floor(timeLeft / 60);
  let sec = timeLeft % 60;
  let timeShown = min + ": " + sec;
  
  pomodoroT.innerHTML = timeShown;
}

function startTimer() {
  interval = setInterval(() => {
    timeLeft--;
    timeUpdate();
  }, 1000) //every 1 second (or 1000 milliseconds), this code will declare hello
}

function stopTimer() {
  console.log("stop");
}

function resetTimer() {
  console.log("reset");
}